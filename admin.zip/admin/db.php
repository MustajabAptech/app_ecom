<?php 
$connection = mysqli_connect('localhost','root','','aptech_ecommerce');
if(! $connection){
 echo "Database connection error";
}