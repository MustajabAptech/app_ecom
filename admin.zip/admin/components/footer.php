<footer class="main-footer">
    <div class="float-right d-none d-sm-block">
      <b>Version</b> 1.1.0
    </div>
    <strong>Copyright &copy; <?php echo date("Y")?> <a href="https://adminlte.io"> Aptech </a>.</strong> All rights reserved.
  </footer>